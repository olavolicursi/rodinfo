import GridMenuVenda from "../../components/gridMenuVenda";
import Navbar from "../../components/navbar";


function Venda(){
    return(
        <>
            <Navbar />
            <GridMenuVenda />
        </>
    )
}

export default Venda;