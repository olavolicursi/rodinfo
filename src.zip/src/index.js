import React from 'react';
import ReactDOM from 'react-dom/client';
import Venda from './pages/venda';



const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
    <Venda />
  </>
);

